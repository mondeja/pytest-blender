import bpy


class PytestBlenderObjectMoveX(bpy.types.Operator):
    """My Object Moving Script"""

    bl_idname = "abc.move_x"
    bl_label = "Move X by One"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        for obj in scene.objects:
            obj.location.x += 1.0

        return {"FINISHED"}
