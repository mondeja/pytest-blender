import bpy
from . pytest_blender_basic import PytestBlenderObjectMoveX


bl_info = {
    "name": "Move X Axis (archived)",
    "category": "Object",
	"version": (0, 0, 1),
}


def register():
    bpy.utils.register_class(PytestBlenderObjectMoveX)


def unregister():
    bpy.utils.unregister_class(PytestBlenderObjectMoveX)


if __name__ == "__main__":
	register()